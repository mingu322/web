package model;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Date;

public class DAOTest {

	public static void main(String[] args) {
		ProDAO dao = new ProDAO();
//		ProVO vo = new ProVO();
//		vo.setPname("이믕룡");
//		vo.setDept("전자");
//		vo.setTitle("조교수");
//		vo.setHiredate("2023-08-02");
//		dao.insert(vo);
//		System.out.println("등록완료");
		System.out.println(dao.read("511").toString());
	}
}
